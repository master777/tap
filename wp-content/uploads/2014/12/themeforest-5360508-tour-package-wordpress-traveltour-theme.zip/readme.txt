 
This version is ‘2.00’
============================================================
For installation, please open folder "document".
go to "index.html". Read "installation" section.

============================================================

==v2.00== 06/05/2014
- add paypal shortcode
	functions.php
	include/plugin/gdl-paypal.php
	include/plugin/shortcode-generator.php
	style.css
	javascript/jquery.fancybox.js
	include/package-option.php
	single-package.php
	include/plugin/package-item.php
	include/goodlayers-option.php

- fix the search / archive package excerpt
	include/plugin/blog-item.php
	
- hide the nav if there're no current page
- sub nav highlight
	javascript/gdl-script.js
	
- fix accordion inside tab
	include/style-custom.php
	
- fix package price when ribbon is set to none
	single.php
	include/plugin/page-item.php
	
- tabs inside togglebox
	javascript/gdl-script.js
	
- fix duplicate contact form mail ( on some server )
	include/plugin/misc.php
	
- create id to color section
	include/plugin/page-item.php 
	
- add book now button link
	include/plugin/package-item.php
	single-package.php
	include/package-option.php
	
- layerslider version
	functions.php

==v1.02== 27/09/2013
- fix package tag header
	header.php
- fix layer slider stylesheet

==v1.01== 29/08/2013
- Add responsive google map plugin in the TGM suggested list and update single package post demo content
	include/javascript/shortcode/package-content.js
	include/plugin/gdl-tgm-plugin-activation.php


==v1.00== 13/08/2013
* initial released 